"""S1: original admin/data network only; DB candidates and original CLI token, no HTTP."""

import argparse
import hashlib
import importlib
import json
import os
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path
from uuid import uuid4

sys.path.insert(0, str(Path(__file__).parent.parent / "edge"))
http = importlib.import_module("790_http")
original = importlib.import_module("790_select")


def event_digest(rows):
    from t44.services.common import wire

    def binary(value):
        if isinstance(value, (bytes, bytearray)):
            return {"bytes_hex": bytes(value).hex()}
        raise TypeError("Unsupported event snapshot scalar")

    raw = json.dumps(wire(rows), sort_keys=True, separators=(",", ":"), default=binary).encode()
    return hashlib.sha256(raw).hexdigest()


def main(argv=None):
    parser = argparse.ArgumentParser()
    for name in ("identities", "output-dir", "host", "user"):
        parser.add_argument("--" + name, required=True)
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--slots", type=int, default=400)
    parser.add_argument("--control", required=True)
    parser.add_argument("--control-sha256", required=True)
    args = parser.parse_args(argv)
    http.configure(args.control, args.control_sha256)
    if not 1 <= args.slots <= 500:
        raise http.InvalidDiagnostic("Bounded slot count required")
    _settings, mysql = original.guarded_settings(args.host, args.port, args.user)
    identities = http.private_json(args.identities)
    if set(identities) != {"manager", "developer", "reviewer"} or any(
        set(value) != {"username", "user_id"} or type(value["user_id"]) is not int
        for value in identities.values()
    ):
        raise http.InvalidDiagnostic("Identity-only explicit three-role mapping required")
    directory = Path(args.output_dir)
    if not directory.is_absolute():
        raise http.InvalidDiagnostic("New absolute output directory required")
    directory.mkdir(mode=0o700)
    status_fd, candidate_fd = http.reserve(directory / "status.public.jsonl"), None
    engine, writes_started, phase = None, False, "database_candidates"
    try:
        from t44.persistence import SqlAlchemyUnitOfWorkFactory, create_mysql_engine
        from t44.services.common import task_model

        engine = create_mysql_engine(mysql)
        factory = SqlAlchemyUnitOfWorkFactory(engine)
        with factory() as uow:
            g = uow.gateway
            projects, transitions, escalations, rule_version = original.candidates(
                g,
                identities,
                args.slots,
                http.parse_utc(http.CONTROL["anchor_at"]),
                lambda value: http.write_fd(status_fd, value),
            )
            selected = [
                row["id"] for pair in zip(transitions, escalations, strict=True) for row in pair
            ]
            selected_events = g.count("escalation_events", {"task_id": selected})
            event_rows_before = g.rows("escalation_events", {})
            events_before = len(event_rows_before)
            event_sha_before = event_digest(event_rows_before)
            http.write_fd(
                status_fd,
                {
                    "kind": "pre_service_event_observation",
                    "utc": http.utc(),
                    "selected_existing_events": selected_events,
                    "total_events": events_before,
                    "event_rows_sha256": event_sha_before,
                },
            )
            if selected_events:
                raise http.InvalidDiagnostic(
                    "Selected fixture already has escalation events; preserve and review"
                )
            slots = [
                {"transition": task_model(left), "escalation": task_model(right)}
                for left, right in zip(transitions, escalations, strict=True)
            ]
        candidate_fd = http.reserve(directory / "candidate.private.json")
        service_path = directory / "service.private.json"
        command = [
            sys.executable,
            "-m",
            "t44.cli",
            "service-token",
            "--name",
            "contrast790s1-" + uuid4().hex,
            "--token-file",
            str(service_path),
        ]
        for identifier in projects:
            command.extend(("--project-id", str(identifier)))
        phase, writes_started = "original_service_token_cli", True
        budget = http.remaining_timeout(60)
        result = subprocess.run(
            command,
            stdin=subprocess.DEVNULL,
            capture_output=True,
            check=False,
            timeout=budget,
        )
        if result.returncode:
            raise http.InvalidDiagnostic("Original CLI failed")
        service = http.private_json(service_path)
        phase = "service_scope_and_event_verification"
        http.remaining_timeout(60)
        with factory() as uow:
            g = uow.gateway
            session = g.get("auth_sessions", service["session_id"])
            if (
                not session
                or session["actor_kind"] != 2
                or session["project_ids"] != projects
                or session["scopes"] != ["escalation:write"]
                or session["revoked_at"] is not None
                or session["expires_at"] <= datetime.now(UTC)
                or session["token_hash"]
                != hashlib.sha256(service["access_token"].encode()).digest()
            ):
                raise http.InvalidDiagnostic("Actual scoped service session differs")
            service.update(
                actor_kind=session["actor_kind"],
                project_ids=session["project_ids"],
                scopes=session["scopes"],
            )
            event_rows_after = g.rows("escalation_events", {})
            events_after = len(event_rows_after)
            event_sha_after = event_digest(event_rows_after)
            if (
                events_after != events_before
                or event_sha_after != event_sha_before
                or g.count("escalation_events", {"task_id": selected})
            ):
                raise http.InvalidDiagnostic(
                    "Escalation events changed during S1; preserve and review"
                )
        packet = {
            "kind": "contrast790-stage1-candidates",
            "product": http.PRODUCT,
            "database": http.DATABASE,
            **http.context_fields(),
            "created_at": http.utc(),
            "project_ids": projects,
            "identities": identities,
            "rule_version": rule_version,
            "service": service,
            "slots": slots,
            "provenance": {
                "candidate_source": "original target-source SQL and task_model",
                "service_source": "original python -m t44.cli service-token with actual IDs",
                "selected_escalation_events_before": selected_events,
                "total_escalation_events_before": events_before,
                "total_escalation_events_after": events_after,
                "event_rows_sha256_before": event_sha_before,
                "event_rows_sha256_after": event_sha_after,
                "stage1_module_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            },
        }
        http.remaining_timeout(60)
        phase = "write_private_candidate"
        http.write_fd(candidate_fd, packet)
        os.fsync(candidate_fd)
        digest = hashlib.sha256((directory / "candidate.private.json").read_bytes()).hexdigest()
        http.write_fd(
            status_fd,
            {
                "kind": "stage1-complete-not-acceptance",
                "utc": http.utc(),
                "slots": len(slots),
                "project_scope_count": len(projects),
                "candidate_sha256": digest,
                "selection_sha256": hashlib.sha256(
                    json.dumps(slots, sort_keys=True, separators=(",", ":")).encode()
                ).hexdigest(),
                "escalation_events_unchanged": True,
                "event_rows_sha256_before": event_sha_before,
                "event_rows_sha256_after": event_sha_after,
                "http_constructed_or_called": False,
                "diagnostic_valid": True,
            },
        )
        os.fsync(status_fd)
        return 0
    except BaseException as error:
        http.write_fd(
            status_fd,
            {
                "diagnostic_valid": False,
                "utc": http.utc(),
                "phase": phase,
                "failure": type(error).__name__,
                "errno": getattr(error, "errno", None),
                "partial_service_account_or_audit_may_exist": writes_started,
                "http_constructed_or_called": False,
            },
        )
        raise
    finally:
        if engine is not None:
            engine.dispose()
        os.close(status_fd)
        if candidate_fd is not None:
            os.close(candidate_fd)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as error:  # noqa: BLE001 - private failure details must not be printed
        print(json.dumps({"stage1_failed": type(error).__name__}), file=sys.stderr)
        sys.exit(1)
