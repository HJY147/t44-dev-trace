# 753 中性输入与操作协议

本文件不含用例、凭据、预期缺陷或目标结果。源已知为356f29983c904e949245aedfad464efc1bf7b63d；镜像与actual loaded receipt尚未给定，后置据实绑定。

## F账号/环境

FUNCTIONAL_ENVIRONMENT.template.json是形状，不得将null当真实值。环境只放PRIVATE/opaque输入。run_id新建且ASCII字母数字下划线连字符，HTTPS origin仅scheme+host[:port]，connect_ip是真实私网IP，CA原字节放W/functional-input/ca.pem。output_dir填/private/functional-results/实际run_id；原目录不存在。max_seconds<=2400。project_id给预建F独立项目、已赋经理/服务scope；也可null由API创建，但service须实际允许新项目。

manager/developer_a/developer_b/reviewer_a/reviewer_b/outsider为6不同真实user_id与精确username，token为已有原字节会话，expires_at为实际UTC失效时刻，不更改元数据冒充续期。项目经理角色1，开发2，审核3。developer_a须兼有reviewer角色3供系统最低防自审黑盒验证；其他developer_b角色2、reviewer_a/b角色3。manager不作为developer。outsider不加入F项目。service须真实escalation:write且只限F项目。disposable是独立可注销会话，不能复用P或F主会话。expired可用实际60秒TTL service到期会话，保留其真实过期时刻；human特有到期仍分列未执行。login_credentials为专用测试账号实际username/password，不能用主账号。未提供可选会话/凭据时删键，不填假值。

identity填source实际SHA、两manifest原字节SHA、真实镜像config、真实import receipt SHA、冻结OpenAPI SHA。APP/LOAD身份、CA和actual receipt通过独立中性资料交753核验，不能用expected-shape替实际。F/P数据和端口隔离，P在F后首次生成新四会话/800任务inventory及窗口。

## Operator控制通道

W/operator-channel只用于主动公开中性控制请求/事实，不能放测试代码、私钥或凭据。在F容器内映射/private/operator-channel。只有operator_actions实际列出的动作会被请求；未提供能力保持未执行。每条请求最多等待180秒，F总限2400秒。root不读其他PRIVATE文件。

request文件名RUN-NNN.request.json，JSON字段schema=753-neutral-operator-request-v1、run_id、request_id=RUN-NNN、phase=f、action、requested_utc、deadline_utc。response原子写到同目录RUN-NNN.response.json；字段request_id、action须原样绑定，success布尔反映真实命令状态，observed_utc为真实UTC，facts保留可脱敏命令退出码、容器状态、运行标识或原始证据路径+SHA。失败success=false并给error；不得伪写成功或改任务/预期字段。

动作仅F：scheduler_scan_wait（按现有真实配置等待至少一次实际扫描完成并给真实run标识/时段）、scheduler_restart（只重启F scheduler）、notification_delivery_wait（按现有超时/重试配置等待真实处理/降级，不改配置缩门槛）、mq_stop/mq_start（仅F MQ）、api_restart（仅F API）、api_ready_wait（实际就绪观察）、db_stop/db_start（可选，只F DB）。起停必须保留卷/数据。未知/不可用动作不可替代为无操作成功。

## 公开入口

安装：sh PUBLIC/INSTALL_753.sh W /root/t44-r9/r29-load-key-01/load-only-private.pem。需先把本PUBLIC全部包和工具胶囊复制到W/public，保持hash。安装network none且SUT请求0；只LOAD使用既有RSA私钥，不搬至APP或本地。

功能：sh W/public/ENTRY_FUNCTIONAL_753.sh W /绝对/private环境.json RUN_ID。源free Python镜像固定config，容器8CPU/8GiB/PID2048/nofile4096、host私网、无产品源码/DB凭据。

性能准备：sh W/public/ENTRY_PERF_753.sh prepare W RUN_ID /绝对/已解封packet目录（目录含inputs/五文件，session.private.json使用NEUTRAL_753_INPUTS_V1；其余字段沿已给中性形状）。需753先据actual identity发表TARGET_PROFILE_753.json与APPROVAL_753.json。prepare network none，grant默认false，SUT请求0。

性能执行：root仅将新的grant.default-false.json中allow从false改true，另存一份原字节新文件，然后sh W/public/ENTRY_PERF_753.sh execute W RUN_ID /绝对/grant-true.json。窗口内只运行一次；无隐含retry/后继压测。正式core精确SHA81e04666cf05c2932397c5d39521ef881602f3046342e2d4d5605a694e5829bf。

PUBLIC只发表主动批准文件；运行输出均PRIVATE，753再发布脱敏事实与报告。root只读operator通道，或753明确发表的有限进度/结果；原始加密证据由753本地备份/核验。
