#!/bin/sh
# Requires an already verified public kit in a NEW workspace; only opaque install.
set -eu
umask 077
[ "$#" -eq 2 ] || exit 2
workspace=$1
rsa_private=$2
case "$workspace" in /*) ;; *) exit 2 ;; esac
case "$rsa_private" in /*) ;; *) exit 2 ;; esac
[ -d "$workspace/public" ] && [ ! -L "$workspace" ] && [ ! -e "$workspace/runtime" ] && [ ! -e "$workspace/capsule.key" ] || exit 2
# The probe derives only a public fingerprint and confirms the existing image.
sh "$workspace/public/RSA_PROBE_V24.sh" "$rsa_private"
(set -C; printf '%s\n' 'opaque-install-only; no grant' > "$workspace/.install.started")
image=sha256:4f3baf081863a4580b5608699d9a7a8af2d89c3e87abbb60089b630b9102b2a1
# Verify every public field BEFORE any private decryption.
docker run --rm --restart=no --pull=never --network none \
  --cpus 1 --memory 256m --memory-swap 256m --pids-limit 32 --read-only --cap-drop ALL \
  --security-opt no-new-privileges --tmpfs /tmp:rw,nosuid,nodev,size=16m \
  --mount "type=bind,src=$workspace,dst=/private" --entrypoint python3 "$image" \
  /private/public/INSTALL_V24_VERIFY.py verify-public /private
# OAEP/MGF1 SHA256. Output is exclusively a 0600 private file, never stdout.
(set -C; openssl pkeyutl -decrypt -passin pass: -inkey "$rsa_private" \
  -in "$workspace/public/capsule-v24-key.rsa-oaep-sha256" \
  -pkeyopt rsa_padding_mode:oaep -pkeyopt rsa_oaep_md:sha256 \
  -pkeyopt rsa_mgf1_md:sha256 > "$workspace/capsule.key" 2>/dev/null)
[ "$(wc -c < "$workspace/capsule.key")" -eq 32 ] || exit 2
chmod 600 "$workspace/capsule.key"
docker run --rm --restart=no --pull=never --network none \
  --cpus 1 --memory 256m --memory-swap 256m --pids-limit 32 --read-only --cap-drop ALL \
  --security-opt no-new-privileges --tmpfs /tmp:rw,nosuid,nodev,size=16m \
  --mount "type=bind,src=$workspace,dst=/private" --entrypoint python3 "$image" \
  /private/public/INSTALL_V24_VERIFY.py install /private
printf '%s\n' '{"status":"OPAQUE_INSTALL_FINISHED","grant_allow":false,"SUT_requests":0,"old_install_or_grant_replayed":false}'
