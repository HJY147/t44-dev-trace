#!/bin/sh
# Read-only metadata probe. No decrypt, files written, registry/SUT calls or grant.
set -eu
[ "$#" -eq 1 ] || exit 2
candidate=$1
case "$candidate" in /*) ;; *) exit 2 ;; esac
expected_der=385f2632f9c82260639db1c0994ebf951a9c1e9efa97a2cd5249b190220f5e66
image=sha256:4f3baf081863a4580b5608699d9a7a8af2d89c3e87abbb60089b630b9102b2a1
for tool in openssl docker sha256sum stat tar; do
  command -v "$tool" >/dev/null 2>&1 || { printf '%s\n' '{"status":"BLOCKED","code":"MISSING_EXISTING_TOOL"}'; exit 2; }
done
[ -f "$candidate" ] && [ ! -L "$candidate" ] || { printf '%s\n' '{"status":"BLOCKED","code":"RSA_PRIVATE_CANDIDATE_NOT_REGULAR"}'; exit 2; }
mode=$(stat -c '%a' "$candidate")
case "$mode" in 400|600) ;; *) printf '%s\n' '{"status":"BLOCKED","code":"RSA_PRIVATE_MODE"}'; exit 2 ;; esac
actual_der=$(openssl pkey -in "$candidate" -passin pass: -pubout -outform DER 2>/dev/null | sha256sum)
actual_der=${actual_der%% *}
[ "$actual_der" = "$expected_der" ] || { printf '%s\n' '{"status":"BLOCKED","code":"LOAD_RSA_PUBLIC_FINGERPRINT_MISMATCH"}'; exit 2; }
actual_image=$(docker image inspect --format '{{.Id}}' "$image" 2>/dev/null)
[ "$actual_image" = "$image" ] || { printf '%s\n' '{"status":"BLOCKED","code":"EXISTING_LOAD_IMAGE_MISMATCH"}'; exit 2; }
if command -v curl >/dev/null 2>&1; then curl_present=true; else curl_present=false; fi
printf '{"status":"READONLY_RSA_AND_IMAGE_MATCH","rsa_public_der_sha256":"%s","existing_load_image":"%s","curl_present":%s,"private_key_material_emitted":false,"SUT_requests":0,"grant_consumed":false}\n' "$actual_der" "$image" "$curl_present"
