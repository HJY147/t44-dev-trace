#!/usr/bin/env python3
"""Public opaque installation only. Never import or run the private test tool."""
import contextlib,hashlib,importlib.util,io,json,os,stat,sys
from pathlib import Path
os.umask(0o077)
CORE='81e04666cf05c2932397c5d39521ef881602f3046342e2d4d5605a694e5829bf'
OPENAPI='6f07cb53a7d9314240ba93ec490325d3c63dca7e4d077021047e216e7b26f478'
CAPSULE='60daf8ac0e1a7fcdc1714dacd421d04fd4f280ef06c90d77b90d322f71e6d71f'
BOOTSTRAP='09266efde00e382d019365766df68b9f2d78d6e750454aaac76d5e853844bf93'
class Rejected(Exception):pass
def need(ok,code):
 if not ok:raise Rejected(code)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def verify(base):
 base=Path(base);pub=base/'public';manifest=json.loads((pub/'TRANSPORT_V24_0B_MANIFEST.json').read_bytes());need(manifest['schema']=='772-v24-0b-opaque-install-v1','MANIFEST_SCHEMA');need(manifest['capsule_sha256']==CAPSULE and manifest['capsule_bytes']==69195,'CAPSULE_BINDING');need(manifest['private_members']['runtime.py']['sha256']==CORE and manifest['private_members']['openapi.json']['sha256']==OPENAPI,'PRIVATE_CORE_OPENAPI_BINDING');need(manifest['public_files']['bootstrap.py']['sha256']==BOOTSTRAP,'BOOTSTRAP_BINDING')
 for name,expected in manifest['public_files'].items():
  need('/' not in name and name not in ('','..','.'),'FLAT_PUBLIC_NAME');p=pub/name;need(p.is_file() and not p.is_symlink() and p.stat().st_size==expected['bytes'] and digest(p)==expected['sha256'],'PUBLIC_FILE_HASH_OR_SIZE')
 need(digest(pub/'runtime-v2.4.772seal')==CAPSULE,'CAPSULE_BYTES');return manifest

def main():
 try:
  need(len(sys.argv)==3 and sys.argv[1] in ('verify-public','install'),'MODE');base=Path(sys.argv[2]);manifest=verify(base)
  if sys.argv[1]=='verify-public':print(json.dumps({'status':'ALL_PUBLIC_FIELDS_HASHED','files':len(manifest['public_files']),'capsule_sha256':CAPSULE,'SUT_requests':0}));return
  key=base/'capsule.key';dest=base/'runtime';need(key.is_file() and not key.is_symlink() and key.stat().st_mode&0o077==0 and key.stat().st_size==32,'PRIVATE_KEY_BOUND');need(not dest.exists(),'NEW_PRIVATE_DIRECTORY_REQUIRED')
  spec=importlib.util.spec_from_file_location('generic_public_bootstrap',base/'public/bootstrap.py');bootstrap=importlib.util.module_from_spec(spec);spec.loader.exec_module(bootstrap)
  # Preserve the exact authenticated bootstrap; make every member creation O_EXCL.
  original=Path.write_bytes
  def exclusive_write(self,value):
   fd=os.open(self,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
   with os.fdopen(fd,'wb') as f:return f.write(value)
  Path.write_bytes=exclusive_write;old_argv=sys.argv[:];sys.argv=['bootstrap.py',str(base/'public/runtime-v2.4.772seal'),str(key),str(dest)]
  try:
   with contextlib.redirect_stdout(io.StringIO()) as receipt:bootstrap.main()
  finally:Path.write_bytes=original;sys.argv=old_argv
  value=json.loads(receipt.getvalue());need(value['status']=='INSTALLED_PRIVATE' and value['capsule_sha256']==CAPSULE,'BOOTSTRAP_RECEIPT');need({p.name for p in dest.iterdir()}==set(manifest['private_members']),'EXACT_PRIVATE_MEMBER_SET')
  for name,expected in manifest['private_members'].items():
   p=dest/name;need(p.is_file() and not p.is_symlink() and p.stat().st_size==expected['bytes'] and digest(p)==expected['sha256'] and stat.S_IMODE(p.stat().st_mode)&0o077==0,'PRIVATE_MEMBER_HASH_SIZE_MODE')
  need(digest(dest/'runtime.py')==CORE and digest(dest/'openapi.json')==OPENAPI,'EXACT_CORE_AND_OPENAPI');print(json.dumps({'status':'INSTALLED_V24_0B_OPAQUE_ONLY','capsule_sha256':CAPSULE,'capsule_bytes':69195,'private_members_verified':len(manifest['private_members']),'core_sha256':CORE,'openapi_sha256':OPENAPI,'exclusive_member_creation':True,'private_key_or_source_emitted':False,'benchmark_or_preflight_run':False,'grant_created_or_consumed':False,'SUT_requests':0}))
 except BaseException as exc:
  print(json.dumps({'status':'BLOCKED_INSTALL_INCOMPLETE','exception_type':type(exc).__name__,'code':str(exc) if isinstance(exc,Rejected) else 'PRIVATE_INSTALL_REJECTED','private_prefix_retained':True,'private_key_or_source_emitted':False,'SUT_requests':0}));raise SystemExit(2)
if __name__=='__main__':main()
